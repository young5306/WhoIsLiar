-- MySQL dump 10.13  Distrib 8.0.40, for Win64 (x86_64)
--
-- Host: whoisliar.me    Database: liar_game_db
-- ------------------------------------------------------
-- Server version	8.0.42

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `participants_rounds`
--

DROP TABLE IF EXISTS `participants_rounds`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `participants_rounds` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) NOT NULL,
  `has_voted` bit(1) NOT NULL DEFAULT b'0',
  `is_liar` bit(1) NOT NULL,
  `order` int NOT NULL,
  `score` int NOT NULL,
  `participant_id` bigint NOT NULL,
  `round_id` bigint NOT NULL,
  `target_participant_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKqlfxoletd6v9iftkv3pfmhq4d` (`participant_id`),
  KEY `FK6vc31mrcsc311aic33knojf33` (`round_id`),
  KEY `FKa7m5pqgebc6phjwc7t2qqcif2` (`target_participant_id`),
  CONSTRAINT `FK6vc31mrcsc311aic33knojf33` FOREIGN KEY (`round_id`) REFERENCES `rounds` (`id`) ON DELETE CASCADE,
  CONSTRAINT `FKa7m5pqgebc6phjwc7t2qqcif2` FOREIGN KEY (`target_participant_id`) REFERENCES `participants` (`id`),
  CONSTRAINT `FKqlfxoletd6v9iftkv3pfmhq4d` FOREIGN KEY (`participant_id`) REFERENCES `participants` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2397 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `participants_rounds`
--

LOCK TABLES `participants_rounds` WRITE;
/*!40000 ALTER TABLE `participants_rounds` DISABLE KEYS */;
/*!40000 ALTER TABLE `participants_rounds` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-22 11:00:50
